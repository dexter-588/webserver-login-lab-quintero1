<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Simple Login System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="dashboard-card">
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION['fullname'] ?? $_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>!</h1>
        <hr>
        <h3>Simple Login System</h3>
        <p>System Integration and Architecture 1</p>
        <br>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</body>
</html>
