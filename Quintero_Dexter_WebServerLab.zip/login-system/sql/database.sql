-- 1. Create Database
CREATE DATABASE lab_login;

-- 2. Connect to lab_login database, then create table:
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    fullname VARCHAR(100) NOT NULL
);

-- 3. Insert 3 Sample Users (Password for all 3 is: Password123!)
-- The hashes below were generated with PHP password_hash('Password123!', PASSWORD_BCRYPT).
INSERT INTO users (username, password, fullname) VALUES 
('admin', '$2y$10$g0xAcJoYkJBPRe0oEZWjaOwlr4l0UGAe3ZCwAC3VmiRURH8HIF8Iu', 'System Administrator'),
('johndoe', '$2y$10$g0xAcJoYkJBPRe0oEZWjaOwlr4l0UGAe3ZCwAC3VmiRURH8HIF8Iu', 'John Doe'),
('janesmith', '$2y$10$g0xAcJoYkJBPRe0oEZWjaOwlr4l0UGAe3ZCwAC3VmiRURH8HIF8Iu', 'Jane Smith');
